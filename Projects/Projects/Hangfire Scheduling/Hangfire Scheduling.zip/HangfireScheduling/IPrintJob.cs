﻿namespace HangfireScheduling
{
    public interface IPrintJob
    {
        void Print();
    }
}