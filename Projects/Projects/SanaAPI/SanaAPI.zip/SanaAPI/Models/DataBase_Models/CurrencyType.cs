﻿namespace SanaAPI
{
    public class CurrencyType
    {
        public int TypeId { get; set; }
        public string TypeCurrency { get; set; }
        public string PriceType { get; set; }
    }
}
