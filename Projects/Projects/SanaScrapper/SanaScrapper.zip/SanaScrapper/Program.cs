﻿namespace WebScrappingHtmlPage
{
    public class Program
    {
        //Main
        static void Main(string[] args)
        {
            CreateCurrency.Create();
        }
    }
}     