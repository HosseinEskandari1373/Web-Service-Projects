﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CustomerSurvey.Models.Database
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string NationalCode { get; set; }
    }
}
