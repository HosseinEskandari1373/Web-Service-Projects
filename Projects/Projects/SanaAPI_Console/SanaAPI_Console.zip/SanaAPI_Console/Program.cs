﻿using Newtonsoft.Json;
using System;
using System.Net.Http;

namespace SanaAPI
{
    class Program
    {
        //Main Function
        static void Main(string[] args)
        {
            CreateCurrency.Create();
        }
    }
}
