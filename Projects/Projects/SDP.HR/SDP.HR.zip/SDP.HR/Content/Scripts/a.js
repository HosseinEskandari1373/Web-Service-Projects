﻿function f() {
    alert('ssss');
    return "aaaa";
}