﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SanaClient.Security
{
    public class Utilities
    {
        //UserName
        public static readonly string UserName = "h.eskandari";

        //Password
        public static readonly string Password = "hh24132413HH@";

        public static readonly string Url =
            "http://crm2016.sdp.com/Test/XRMServices/2011/Organization.svc";

        //Get Date From System
        public static readonly DateTime DateSubmitted = DateTime.Now;
    }
}
