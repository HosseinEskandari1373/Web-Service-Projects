﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConnectXrmAPI.Dashboard
{
    public class Utilities
    {
        //the URL address for OrganizationService
        public static readonly string ServiceUrl =
            "http://crm2016.sdp.com/Test/XRMServices/2011/Organization.svc";
    }
}
